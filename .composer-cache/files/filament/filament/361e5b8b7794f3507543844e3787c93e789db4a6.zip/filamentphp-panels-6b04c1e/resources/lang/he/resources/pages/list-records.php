<?php

return [

    'breadcrumb' => 'רשימה',

];
