<?php

return [

    'direction' => 'ltr',

    'actions' => [

        'billing' => [
            'label' => 'Administrar suscripción',
        ],

        'logout' => [
            'label' => 'Salir',
        ],

        'open_database_notifications' => [
            'label' => 'Abrir notificaciones',
        ],

        'open_user_menu' => [
            'label' => 'Menú del Usuario',
        ],

        'sidebar' => [

            'collapse' => [
                'label' => 'Contraer barra lateral',
            ],

            'expand' => [
                'label' => 'Expandir barra lateral',
            ],

        ],

        'theme_switcher' => [

            'dark' => [
                'label' => 'A modo oscuro',
            ],

            'light' => [
                'label' => 'A modo claro',
            ],

            'system' => [
                'label' => 'A modo del sistema',
            ],

        ],

    ],

    'avatar' => [
        'alt' => 'Avatar of :name',
    ],

    'logo' => [
        'alt' => ':name logo',
    ],

    'tenant_menu' => [

        'search_field' => [
            'label' => 'Buscar inquilino',
            'placeholder' => 'Buscar',
        ],

    ],

];
